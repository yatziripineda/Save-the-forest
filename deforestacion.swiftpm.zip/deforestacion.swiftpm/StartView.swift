//
//  StartView.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//
import SwiftUI

struct StartView: View {
    @State private var pressbutton = false
    @State private var cloudOffset: CGFloat = 0
    @Binding var currentGameState: GameState
    @State private var heartBeatAnimation = false

    private var screenWidth: CGFloat { UIScreen.main.bounds.size.width }

    var body: some View {
        ZStack{
            VStack {
                Spacer()
                if pressbutton == false{
                    Image("titulo4")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.horizontal, 50.0)
                }
                ZStack{
                    Button(action: {
                        //                        withAnimation {
                        //
                        //                            currentGameState = .playing
                        //                        }
                        //                        ExplanationGameView(currentGameState: $currentGameState)
                        pressbutton = true
                    }) {
                        Text("Start")
                            .bold()
                            .font(.title)
                            .padding(.horizontal, 70)
                            .padding(.vertical, 20)
                            .foregroundColor(Color.black)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(Color.white.opacity(0.9))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 15)
                                            .stroke(Color.black, lineWidth: 2)
                                    )
                                    .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                            )
                            .scaleEffect(currentGameState == .playing ? 0.8 : 1.0)
                    }
                    
                }
                .padding(.top, 100.0)
                Spacer()
            }
            if pressbutton{
                ExplanationGameView(currentGameState: $currentGameState)
            }
        }
        .background(
            ZStack {
                Color(red: 122/255, green: 184/255, blue: 229/255)
                    .ignoresSafeArea()
                    .aspectRatio(contentMode: .fill)

                CloudsView(offset: cloudOffset)
                CloudsView(offset: cloudOffset - screenWidth)
                
            }
        )
        .onAppear {
            withAnimation(Animation.linear(duration: 10).repeatForever(autoreverses: false)) {
                cloudOffset = screenWidth
            }
        }
    }
}


struct CloudsView: View {
    var offset: CGFloat

    var body: some View {
        Image("nuvessincielo")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: UIScreen.main.bounds.size.width  )
            .opacity(0.7)
            .offset(x: offset, y: -90)
    }
}



#Preview {
    StartView(currentGameState: .constant(.firstTime))
}
