//
//  GameScoreView.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//
import SwiftUI

struct GameScoreView: View {
    @Binding var score: Int
    
    var body: some View {
        ZStack{
//            RoundedRectangle(cornerRadius: 15)
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white.opacity(0.4))
                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
//             
            HStack {
                Image("sol1")
                    .resizable()
                    .frame(width: 50, height: 50)
                    
                Text("Score: ")
                    .font(.title)
//                    .bold()
                    .foregroundColor(.black)
                Spacer()
                Text("\(score)")
                    .bold()
                    .font(.title)
                    .foregroundColor(.black)
                    .padding()
            }.padding()
        }
        .frame(width: 330, height: 70)
        .padding(24)
            

//        .cornerRadius(10)
    }
}

#Preview {
    GameScoreView(score: .constant(100))
        .previewLayout(.fixed(width: 300, height: 100))
}
