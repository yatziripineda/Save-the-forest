//
//  SwiftUIView.swift
//  
//
//  Created by yatziri on 23/02/24.
//

import SwiftUI

struct FourthPagueView: View {
    var body: some View {
        HStack {
            VStack(alignment: .leading){
                HStack{
                    Text("Collect ")
                        .font(.title)
                        .foregroundColor(.white)
                    
                    Text("5 suns  ")
                        .bold()
                        .font(.largeTitle)
                        .foregroundColor(.white)
                }
                    Text("to enhance Ramon's energy and make him more resistant to any damage. ")
                        .font(.title)
                        .foregroundColor(.white)
                
            }
            .padding()
            .padding(.leading, 20.0)
            VStack{
                Image("sol1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width * 0.1, height: UIScreen.main.bounds.height * 0.1)
                    .padding()
                Image("arbolsalto4")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width * 0.3, height: UIScreen.main.bounds.height * 0.3)
                    .padding()
            }
            
        }
        
    }}

#Preview {
    FourthPagueView()
}
