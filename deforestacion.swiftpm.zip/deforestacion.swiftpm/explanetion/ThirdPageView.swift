//
//  SwiftUIView.swift
//  
//
//  Created by yatziri on 23/02/24.
//

import SwiftUI

struct  ThirdPageView: View {
    var body: some View {
        HStack {
            VStack(alignment: .leading){
                HStack{
                    Text("You would only have ")
                        .font(.title)
                        .foregroundColor(.white)
                    Text("3 lives,")
                        .bold()
                        .font(.largeTitle)
                        .foregroundColor(.white)
                }
                Text("or Ramon will become one more tree in the history of deforestation.")
                    .font(.title)
                    .foregroundColor(.white)
            }
            .padding()
            .padding(.leading, 20.0)
            VStack{
                Image("vidas")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width / (CGFloat(3) + 1.0), height: UIScreen.main.bounds.height / (CGFloat(3) + 6.0))
                    .padding()
                Image("vidas")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width / (CGFloat(3) + 1.0), height: UIScreen.main.bounds.height / (CGFloat(3) + 6.0))
                    .padding()
                Image("vidas")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width / (CGFloat(3) + 1.0), height: UIScreen.main.bounds.height / (CGFloat(3) + 6.0))
                    .padding()
            }
        }
        
    }
}

#Preview {
    ThirdPageView()
}
