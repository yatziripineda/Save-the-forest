//
//  SwiftUIView.swift
//  
//
//  Created by yatziri on 23/02/24.
//

import SwiftUI

struct SecondPageView: View {
    var body: some View {
        HStack {
            VStack(alignment: .leading){
                Text("In which he needs to avoid fires and lumberjacks ")
                    .font(.title)
                    .foregroundColor(.white)
                HStack{
                    Text("jumping ")
                        .bold()
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    Text("over them.")
                        .font(.title)
                        .foregroundColor(.white)
                }
            }
            .padding()
            .padding(.leading, 20.0)
            VStack{
                Image("fuego2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width / (CGFloat(2) + 1.0), height: UIScreen.main.bounds.height / (CGFloat(2) + 2.5))
                    .padding()
                Image("lenador1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UIScreen.main.bounds.width / (CGFloat(2) + 1.0), height: UIScreen.main.bounds.height / (CGFloat(2) + 2.5))
                    .padding()
            }
            
        }
        
    }
}
//("In which he needs to avoid fires and lumberjacks jumping over them.", ["fuego2", ""]),
#Preview {
    SecondPageView()
}
