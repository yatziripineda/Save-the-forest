//
//  FirstPageView.swift
//  deforestacion
//
//  Created by yatziri on 23/02/24.
//

import SwiftUI

struct FirstPageView: View {
    //    var description: String
    //    var images: [String]?
    
    var body: some View {
        HStack {
            VStack (alignment: .leading){
                HStack{
                    Text("Help ")
                        .font(.title)
                        .foregroundColor(.white)
//                        .padding(.leading, 20.0)
                    
                    Text("Ramon ")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .bold()
                }
                Text("navigate a world threatened by deforestation and climate change.")
                    .font(.title)
                    .foregroundColor(.white)
//                    .padding()
                
            }
            .padding()
            .padding(.leading, 20.0)
            
            Image("arbol1")
                .resizable()
                .scaledToFit()
                .frame(width: UIScreen.main.bounds.width * 0.3, height: UIScreen.main.bounds.height * 0.40)
                .padding()
            
            
        }
        
    }
}


#Preview {
    FirstPageView()
}
