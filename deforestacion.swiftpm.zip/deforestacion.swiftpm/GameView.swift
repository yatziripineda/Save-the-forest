//
//  GameView.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//

import SwiftUI
import SpriteKit

struct GameView: View {
    
    @StateObject var gameLogic: ArcadeGameLogic = ArcadeGameLogic.shared
    @Binding var currentGameState: GameState
    @State private var isWinViewPresented = false
    private var screenWidth: CGFloat { UIScreen.main.bounds.size.width }
    private var screenHeight: CGFloat { UIScreen.main.bounds.size.height }
    
    var arcadeGameScene: GameScene {
        let scene = GameScene()
        scene.size = CGSize(width: screenWidth, height: screenHeight)
        scene.scaleMode = .fill
        return scene
    }
    
    var body: some View {
        
        ZStack(alignment: .top) {
            SpriteView(scene: self.arcadeGameScene)
                .frame(width: screenWidth, height: screenHeight)
                .position(CGPoint(x: screenWidth / 2 , y: screenHeight / 2))
                .ignoresSafeArea()
                .statusBar(hidden: true)
            
            if isWinViewPresented == false{
                HStack() {
                    GameDurationView(lives: $gameLogic.liveScore)
                    
                    Spacer()
                    
                    GameScoreView(score: $gameLogic.currentScore)
                }
                .padding()
                .padding(.top, 40)
            }
            if isWinViewPresented {
                winview(currentGameState: $currentGameState)
            }
            
        }
        .onChange(of: gameLogic.currentScore) { score in
            if score == 5 {
                self.isWinViewPresented = true
            }
            else {
                self.isWinViewPresented = false
            }
        }
        .onChange(of: gameLogic.liveScore) { newLiveScore in
            if newLiveScore == 0 {
                withAnimation {
                    self.presentGameOverScreen()
                }
            }
        }
        
        .onAppear {
            gameLogic.restart_Game()
        }
    }

    private func presentGameOverScreen() {
        self.currentGameState = .gameOver
    }
}


#Preview {
    StartView(currentGameState: .constant(.playing))
}

