//
//  GameOverView.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//

import SwiftUI

/**
 * # GameOverView
 *   This view is responsible for showing the game over state of the game.
 *  Currently it only present buttons to take the player back to the main screen or restart the game.
 *
 *  You can also present score of the player, present any kind of achievements or rewards the player
 *  might have accomplished during the game session, etc...
 **/




struct GameOverView: View {
    
    @Binding var currentGameState: GameState
    
    var body: some View {
        ZStack{
            Color(red: 122/255, green: 184/255, blue: 229/255)
                .ignoresSafeArea()
                .aspectRatio(contentMode: .fill)
            
            VStack(alignment: .center) {
                Spacer()
                Image("lost")
                    .padding(.bottom, 50.0)
//                Spacer()
                
                Button {
                    withAnimation { self.backToMainScreen() }
                } label: {
                    HStack{
                        Image(systemName: "house.fill")
                        Text("Home")
                            
                    }.bold()
                        .font(.title)
                        .padding(.horizontal, 90)
                        .padding(.vertical, 20)
                        .foregroundColor(Color.black)
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.white.opacity(0.9))
                                
                                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                        )
                        .scaleEffect(currentGameState == .playing ? 0.8 : 1.0)
                }
                .padding()
                Button {
                    withAnimation { self.restartGame() }
                } label: {
                    HStack{
                        Image(systemName: "arrow.clockwise")
                        Text("Restart")
                            
                    }.bold()
                        .font(.title)
                        .padding(.horizontal, 90)
                        .padding(.vertical, 20)
                        .foregroundColor(Color.black)
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.white.opacity(0.9))
                                
                                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                        )
                        .scaleEffect(currentGameState == .playing ? 0.8 : 1.0)
                }
                .padding()

                
                Spacer()
            }
        }             
        
        .statusBar(hidden: true)
    }
    
    private func backToMainScreen() {
        self.currentGameState = .firstTime
    }
    
    private func restartGame() {
        self.currentGameState = .playing
    }
}


//
//struct GameOverView: View {
//
//    @Binding var currentGameState: GameState
//
//    var body: some View {
//        ZStack {
//            Color.white
//                .ignoresSafeArea()
//
//            VStack(alignment: .center) {
//                Spacer()
//
//                Button {
//                    withAnimation { self.backToMainScreen() }
//                } label: {
//                    Image(systemName: "arrow.backward")
//                        .foregroundColor(.black)
//                        .font(.title)
//                }
//                .background(Circle().foregroundColor(Color(uiColor: UIColor.systemGray6)).frame(width: 100, height: 100, alignment: .center))
//
//                Spacer()
//
//                Button {
//                    withAnimation { self.restartGame() }
//                } label: {
//                    Image(systemName: "arrow.clockwise")
//                        .foregroundColor(.black)
//                        .font(.title)
//                }
//                .background(Circle().foregroundColor(Color(uiColor: UIColor.systemGray6)).frame(width: 100, height: 100, alignment: .center))
//
//                Spacer()
//            }
//        }
//        .statusBar(hidden: true)
//    }
//
//    private func backToMainScreen() {
//        self.currentGameState = .chooseChar
//    }
//
//    private func restartGame() {
//        self.currentGameState = .playing
//    }
//}

#Preview {
    GameOverView(currentGameState: .constant(GameState.gameOver))
}

