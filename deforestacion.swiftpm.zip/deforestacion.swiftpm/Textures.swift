//
//  Textures.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//


import Foundation
import SpriteKit

class Textures {
    let arbolParado: [SKTexture] = [SKTexture(imageNamed: "arbol1")
    ]
    
    let arbolsalto : [SKTexture] = [SKTexture(imageNamed: "arbolsalto1"),
                                    SKTexture(imageNamed: "arbolsalto2"),
                                    SKTexture(imageNamed: "arbolsalto3"),
                                    SKTexture(imageNamed: "arbolsalto4"),
                                    SKTexture(imageNamed: "arbolsalto5"),
                                    SKTexture(imageNamed: "arbolsalto4"),
                                    SKTexture(imageNamed: "arbolsalto3"),
                                    SKTexture(imageNamed: "arbolsalto2"),
                                    SKTexture(imageNamed: "arbolsalto1")
    ]
    let triste : [SKTexture] = [
                                    SKTexture(imageNamed: "triste1"),
                                    SKTexture(imageNamed: "triste2"),
                                    SKTexture(imageNamed: "triste3"),
                                    SKTexture(imageNamed: "triste4"),
                                    SKTexture(imageNamed: "triste5"),
                                    SKTexture(imageNamed: "triste6"),
                                    SKTexture(imageNamed: "triste7"),
                                    SKTexture(imageNamed: "triste8"),
                                    SKTexture(imageNamed: "triste9"),
                                    SKTexture(imageNamed: "triste10"),
                                    SKTexture(imageNamed: "triste11")
    ]
    let arboldcaminar: [SKTexture] = [SKTexture(imageNamed: "caminar1"),
                                       SKTexture(imageNamed: "caminar2"),
                                       SKTexture(imageNamed: "caminar3")
    ]
    
    let bgLayerTextures: [(SKTexture, TimeInterval, CGFloat, CGFloat)] = [
        (SKTexture(imageNamed: "fondo6"), 8, 1.0, 0),
//        (SKTexture(imageNamed: "fondo1.1"), 9, 1.0, 0),
        (SKTexture(imageNamed: "fondo1.2"), 10, 1.0, 0),
        (SKTexture(imageNamed: "fondo1.3"), 11, 1.0, 0),
        (SKTexture(imageNamed: "nuvessincielo"), 10, 2.0, 200)
        
    ]

    let pastoLayerTextures : [(SKTexture, CGFloat)]  = [(
//                                                    SKTexture(imageNamed:"sueloedificiofinal"),10),
                                                     SKTexture(imageNamed: "fondo1"), 15),
                                                     (SKTexture(imageNamed: "fondo2"), 15),
                                                     (SKTexture(imageNamed: "fondo3"), 15)
    ]
    
    let fuego : [SKTexture] = [SKTexture(imageNamed: "fuego1"),
                                       SKTexture(imageNamed: "fuego2"),
                                       SKTexture(imageNamed: "fuego3"),
                                       SKTexture(imageNamed: "fuego4"),
                                       SKTexture(imageNamed: "fuego5"), 
                                       SKTexture(imageNamed: "fuego6")
    ]
    let lenador : [SKTexture] = [SKTexture(imageNamed: "lenador1"),
                                       SKTexture(imageNamed: "lenador2"),
                                       SKTexture(imageNamed: "lenador3")
    ]
    let sol : [SKTexture] = [SKTexture(imageNamed: "sol1"),
                                       SKTexture(imageNamed: "sol2"),
                                       SKTexture(imageNamed: "sol3"),
                                       SKTexture(imageNamed: "sol4")
    ]
    let arbolsol : [SKTexture] = [SKTexture(imageNamed: "arbolsol1"),
                                  SKTexture(imageNamed: "arbolsol2"),
                                  SKTexture(imageNamed: "arbolsol3"),
                                  SKTexture(imageNamed: "arbolsol4"),
                                  SKTexture(imageNamed: "arbolsol3"),
                                  SKTexture(imageNamed: "arbolsol2"),
                                  SKTexture(imageNamed: "arbolsol1"),
    ]
    
   
    
    
    
    

}

