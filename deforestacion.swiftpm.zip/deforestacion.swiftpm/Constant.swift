//
//  Constant.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//

import Foundation
import SwiftUI



enum GameState {
    case firstTime
//    case win
    case playing
    case pause
    case gameOver
}



