//
//  GameScene.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//

import SpriteKit
import GameplayKit
import AVFoundation
import SwiftUI

class GameScene: SKScene {
    
    //    weak var gameVC : GameViewController?
    
    var gameLogic: ArcadeGameLogic = ArcadeGameLogic.shared
    
    var heroInAir = false
    var gameIsEnd = false {
        didSet {
            endGame()
        }
    }
    
    var gameIsPaused = false
    
    var timeInterval: TimeInterval = 4.0
    var fast: TimeInterval = 10.0
    
    
    var jumpCount = 0
    
    var timer = Timer()
    
    var heroNodeTexture = SKTexture(imageNamed: "Warrior_Run_1")
    var heroSpriteNode = SKSpriteNode()
    var heroNode = SKNode()
    
    var backGroundNodeArray = [SKNode]()
    var enemyNodeArray = [SKNode]()
    var pointNodeArray = [SKNode]()
    
    var groundSpriteNode = SKSpriteNode()
    var groundNode = SKNode()
    
    var wallSpriteNode = SKSpriteNode()
    var wallNode = SKNode()
    
    var secondWallSpriteNode = SKSpriteNode()
    var secondWallNode = SKNode()
    
    let textures = Textures()
    
    
    //    var musicNode = SKAudioNode()
    
    var heroMask : UInt32 = 1
    var groundMask : UInt32 = 2
    var wallMask : UInt32 = 3
    var enemyMask : UInt32 = 4
    var pointMask : UInt32 = 5
    var bosqueMask : UInt32 = 6
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        
        initialSetUp()
    }
    
    func initialSetUp() {
        let backgroundNode = SKSpriteNode(color: UIColor(red: 122/255, green: 184/255, blue: 229/255, alpha: 1.0), size: size)
        backgroundNode.position = CGPoint(x: size.width / 2, y: size.height / 2)
        backgroundNode.zPosition = -10
        addChild(backgroundNode)
        physicsWorld.contactDelegate = self
        physicsWorld.gravity = CGVector(dx: -4, dy: -9.8)
        
        addBackground()
        createHero()
        createGround()
        createWall()
        //        createAudio()
        startSpawn()
        addChild(heroNode)
        addChild(groundNode)
        addChild(wallNode)
        addChild(secondWallNode)
        //        addChild(musicNode)
    }
    
    
    func addBackgroundLayer(texture: SKTexture, speed: TimeInterval, zPosOffset: CGFloat, scale: CGFloat, initialY: CGFloat) {
        let node = SKNode()
        let moveBackground = SKAction.moveBy(x: -texture.size().width * scale, y: 0, duration: speed)
        
        let replaceBackground = SKAction.moveBy(x: texture.size().width * scale, y: 0, duration: 0)
        
        let moveBackgroundInf = SKAction.repeatForever(SKAction.sequence([moveBackground, replaceBackground]))
        
        for i in 0..<3 {
            let sprite = SKSpriteNode(texture: texture)
            
            // La posición ahora depende de la anchura de la textura y de la posición inicial en Y
            let initialX = size.width * CGFloat(i)
            let initialPosition = CGPoint(x: initialX, y: initialY)
            sprite.position = initialPosition
            
            // Escala basada en el parámetro scale
            sprite.setScale(scale)
            
            sprite.zPosition = -zPosOffset
            sprite.run(moveBackgroundInf)
            node.addChild(sprite)
        }
        
        backGroundNodeArray.append(node)
        addChild(node)
    }
    
    
    
    func addBackground() {
        var index = 0
        
        for (texture, speed, scale, initialY) in textures.bgLayerTextures {
            addBackgroundLayer(texture: texture, speed: speed, zPosOffset: CGFloat(index), scale: scale, initialY: initialY)
            index += 1
        }
    }
    
    
    
    func createGround() {
        groundSpriteNode.position = CGPoint.zero
        groundSpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: size.width * 2, height: 60))
        groundSpriteNode.physicsBody?.isDynamic = false
        groundSpriteNode.physicsBody?.categoryBitMask = groundMask
        groundSpriteNode.zPosition = 1
        
        groundNode.addChild(groundSpriteNode)
    }
    
    func createWall() {
        
        wallSpriteNode.position = CGPoint.zero
        wallSpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 100, height: size.height * 2))
        wallSpriteNode.physicsBody?.isDynamic = false
        wallSpriteNode.physicsBody?.categoryBitMask = wallMask
        wallSpriteNode.zPosition = 1
        
        secondWallSpriteNode.position = CGPoint(x: size.width + 100, y: 0)
        secondWallSpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 60, height: size.height * 2))
        secondWallSpriteNode.physicsBody?.isDynamic = false
        secondWallSpriteNode.physicsBody?.categoryBitMask = wallMask
        secondWallSpriteNode.zPosition = 1
        
        secondWallNode.addChild(secondWallSpriteNode)
        wallNode.addChild(wallSpriteNode)
    }
    
    func addHero(at position: CGPoint) {
        heroSpriteNode = SKSpriteNode(texture: heroNodeTexture)
        let heroRunAnimation = SKAction.animate(with: textures.arboldcaminar, timePerFrame: 0.1)
        let heroRun = SKAction.repeatForever(heroRunAnimation)
        heroSpriteNode.run(heroRun)
        
        heroSpriteNode.position = position
        heroSpriteNode.zPosition = 1
        heroSpriteNode.setScale(2.0)
        heroSpriteNode.yScale *= 1.5
        
        
        heroSpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: heroNodeTexture.size().width * 2 - 30, height: heroNodeTexture.size().height * 2 + 10))
        heroSpriteNode.physicsBody?.mass = 0.3
        heroSpriteNode.physicsBody?.categoryBitMask = heroMask
        heroSpriteNode.physicsBody?.contactTestBitMask = groundMask
        heroSpriteNode.physicsBody?.collisionBitMask = groundMask
        
        
        heroSpriteNode.physicsBody?.isDynamic = true
        heroSpriteNode.physicsBody?.allowsRotation = false
        let move = SKAction.applyImpulse(CGVector(dx: -100, dy: 0), duration: 0.1)
        heroSpriteNode.run(move)
        
        heroNode.addChild(heroSpriteNode)
    }
    
    func createHero() {
        addHero(at: CGPoint(x: size.width / 4, y: size.height / 4))
        
    }
    
    
    func createpoint(at position: CGPoint) {
        let pointNode = SKNode()
        let pointSpriteNode = SKSpriteNode(texture: textures.sol[0])
        let pointAnimation = SKAction.animate(with: textures.sol, timePerFrame: 0.1)
        let pointAnimationRepeat = SKAction.repeatForever(pointAnimation)
        pointSpriteNode.run(pointAnimationRepeat)
        
        pointSpriteNode.position = position
        pointSpriteNode.zPosition = 1
        pointSpriteNode.setScale(1)
        pointSpriteNode.xScale *= 1
        
        pointSpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: heroNodeTexture.size().width - 30, height: heroNodeTexture.size().height + 10))
        pointSpriteNode.physicsBody?.categoryBitMask = pointMask
        pointSpriteNode.physicsBody?.contactTestBitMask = heroMask
        pointSpriteNode.physicsBody?.collisionBitMask = groundMask
        
        pointSpriteNode.physicsBody?.isDynamic = true
        pointSpriteNode.physicsBody?.affectedByGravity = false
        pointSpriteNode.physicsBody?.allowsRotation = false
        
        
        let move = SKAction.applyImpulse(CGVector(dx: -300, dy: 0), duration: 0.025)
        pointSpriteNode.run(move)
        if  pointSpriteNode.position.x < heroSpriteNode.position.x{
            let move1 = SKAction.applyImpulse(CGVector(dx: -500, dy: 0), duration: 0.025)
            pointSpriteNode.run(move1)
        }
        
        pointNodeArray.append(pointNode)
        pointNode.addChild(pointSpriteNode)
        addChild(pointNode)
    }
    
    func createEnemy_Le() {
        let enemyNode = SKNode()
        let enemySpriteNode = SKSpriteNode(texture: textures.lenador[0])
        let enemyAnimation = SKAction.animate(with: textures.lenador, timePerFrame: 0.1)
        let enemyAnimationRepeat = SKAction.repeatForever(enemyAnimation)
        enemySpriteNode.run(enemyAnimationRepeat)
        
        enemySpriteNode.position = CGPoint(x: size.width, y: size.height / 6)
        enemySpriteNode.zPosition = 1
        enemySpriteNode.setScale(1)
        enemySpriteNode.xScale *= 1
        
        enemySpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: heroNodeTexture.size().width , height: heroNodeTexture.size().height ))
        enemySpriteNode.physicsBody?.categoryBitMask = enemyMask
        enemySpriteNode.physicsBody?.contactTestBitMask = heroMask
        enemySpriteNode.physicsBody?.collisionBitMask = groundMask
        
        enemySpriteNode.physicsBody?.isDynamic = true
        enemySpriteNode.physicsBody?.affectedByGravity = false
        enemySpriteNode.physicsBody?.allowsRotation = false
        
        
        let move = SKAction.applyImpulse(CGVector(dx: -300, dy: 0), duration: 0.025)
        enemySpriteNode.run(move)
        if  enemySpriteNode.position.x < heroSpriteNode.position.x{
            let move1 = SKAction.applyImpulse(CGVector(dx: -500, dy: 0), duration: 0.025)
            enemySpriteNode.run(move1)
        }
        
        enemyNodeArray.append(enemyNode)
        enemyNode.addChild(enemySpriteNode)
        addChild(enemyNode)
    }
    func createEnemy_Fuego() {
        let enemyNode = SKNode()
        let enemySpriteNode = SKSpriteNode(texture: textures.fuego[0])
        let enemyAnimation = SKAction.animate(with: textures.fuego, timePerFrame: 0.1)
        let enemyAnimationRepeat = SKAction.repeatForever(enemyAnimation)
        enemySpriteNode.run(enemyAnimationRepeat)
        
        enemySpriteNode.position = CGPoint(x: size.width, y: size.height / 6)
        enemySpriteNode.zPosition = 1
        enemySpriteNode.setScale(0.3)
        enemySpriteNode.xScale *= 1
        
        enemySpriteNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: heroNodeTexture.size().width - 30, height: heroNodeTexture.size().height + 10))
        enemySpriteNode.physicsBody?.categoryBitMask = enemyMask
        enemySpriteNode.physicsBody?.contactTestBitMask = heroMask
        enemySpriteNode.physicsBody?.collisionBitMask = groundMask
        
        enemySpriteNode.physicsBody?.isDynamic = true
        enemySpriteNode.physicsBody?.affectedByGravity = false
        enemySpriteNode.physicsBody?.allowsRotation = false
        
        let move = SKAction.applyImpulse(CGVector(dx: -300, dy: 0), duration: 0.025)
        enemySpriteNode.run(move)
        
        if  enemySpriteNode.position.x < heroSpriteNode.position.x{
            let move1 = SKAction.applyImpulse(CGVector(dx: -500, dy: 0), duration: 0.025) // Ajusta el valor de dx según tu preferencia
            enemySpriteNode.run(move1)
        }
        
        enemyNodeArray.append(enemyNode)
        enemyNode.addChild(enemySpriteNode)
        addChild(enemyNode)
    }
    
    func heroJump() {
        heroInAir = true
        jumpCount += 1
        let jumpy = 270 - (jumpCount * 25)
        let jumpAnimation = SKAction.animate(with: textures.arbolsalto, timePerFrame: 0.1)
        heroSpriteNode.run(jumpAnimation)
        heroSpriteNode.physicsBody?.velocity = CGVector.zero
        
        
        heroSpriteNode.physicsBody?.applyImpulse(CGVector(dx: 150, dy: jumpy))
        print(heroSpriteNode.position.y )
        
    }
    func heroDied() {
        let tristeAnimation = SKAction.animate(with: textures.triste, timePerFrame: 0.15)
        //        heroSpriteNode.setScale(1)
        heroSpriteNode.run(tristeAnimation) {
            self.gameLogic.lives(points: 1)
            print("lives: \(self.gameLogic.liveScore)")
            
            // Reset the opacity when the drag respawns or when needed
            let fadeInAction = SKAction.fadeAlpha(to: 1.0, duration: 0.1)
            self.heroSpriteNode.run(fadeInAction)
        }
        if gameLogic.liveScore == 0 {
            self.restartGame()
        }
    }
    
    func startSpawn() {
        var randomDelay =  8.0
//        if gameLogic.currentScore < 2{
            timer = Timer.scheduledTimer(withTimeInterval: randomDelay, repeats: true) { _ in
                randomDelay = Double.random(in: 5...7)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + randomDelay) {
                    let randomY = CGFloat.random(in: self.size.height / 2..<self.size.height * 5 / 6)
                    if self.gameLogic.currentScore < 5{
                        self.createpoint(at: CGPoint(x: self.size.width, y: randomY))
                    }
                }
            }
            timer = Timer.scheduledTimer(withTimeInterval: 7, repeats: true) { _ in
                let enemy = Bool.random()
                if self.gameLogic.currentScore < 5{
                    if enemy{
                        self.createEnemy_Le()
                    } else{
                        self.createEnemy_Fuego()
                    }
                }
                
            }
//        }
    }
    
    private func restartGame() {
        self.gameLogic.restart_Game()
        timeInterval = 4.0
        fast = 10.0
        gameIsEnd = true
    }
    
    func endGame() {
        if gameIsEnd == true {
            timer.invalidate()
            children.forEach { node in
                node.removeAllActions()
                node.children.forEach { node in
                    node.removeAllActions()
                }
            }
            
            enemyNodeArray.forEach { node in
                node.removeFromParent()
            }
            
           
            Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                let blurView = UIVisualEffectView(frame: self.frame)
                blurView.alpha = 1
                blurView.layer.zPosition = 2
                
                UIView.animate(withDuration: 3) {
                    blurView.effect = UIBlurEffect(style: UIBlurEffect.Style.extraLight)
                }
            }
        }
        
    }
}

//var heroMask : UInt32 = 1
//var groundMask : UInt32 = 2
//var wallMask : UInt32 = 3
//var enemyMask : UInt32 = 4

extension GameScene: SKPhysicsContactDelegate {
    func didBegin(_ contact: SKPhysicsContact) {
//MARK: -         si el heroe choca con el piso
        if contact.bodyA.categoryBitMask == 1 && contact.bodyB.categoryBitMask == 2 {
            heroInAir = false
            jumpCount = 0
//            if gameIsPaused {
//                physicsWorld.gravity = CGVector(dx: 0, dy: -10)
//            }
        }
//  MARK: -       si el enemy choca con el heroe
        if contact.bodyA.categoryBitMask == 4 && contact.bodyB.categoryBitMask == 1 || contact.bodyA.categoryBitMask == 1 && contact.bodyB.categoryBitMask == 4 {
//            gameIsPaused = true
            heroInAir = false
            jumpCount = 0
            heroDied()
//            physicsWorld.gravity = CGVector(dx: 0, dy: -10)
        }
//  MARK: -       si el sol choca con el heroe
        if contact.bodyA.categoryBitMask == 5 && contact.bodyB.categoryBitMask == 1 || contact.bodyA.categoryBitMask == 1 && contact.bodyB.categoryBitMask == 5 {
            let solAnimation = SKAction.animate(with: textures.arbolsol, timePerFrame: 0.07)
            jumpCount = 3
            heroSpriteNode.run(solAnimation)
            self.gameLogic.score(points: 1)
            
            if contact.bodyA.categoryBitMask == 5 {
                contact.bodyA.node?.removeFromParent()
                
            } else {
                contact.bodyB.node?.removeFromParent()
                
            }
            //            physicsWorld.gravity = CGVector(dx: 0, dy: -10)
        }
        
//  MARK: -       si el enemy choca con la pared
        if contact.bodyA.categoryBitMask == 4 && contact.bodyB.categoryBitMask == 3 || contact.bodyA.categoryBitMask == 3 && contact.bodyB.categoryBitMask == 4 {
            if contact.bodyA.categoryBitMask == 4 {
                contact.bodyA.node?.removeFromParent()
            } else {
                contact.bodyB.node?.removeFromParent()
            }
        }
 //  MARK: -       si el sol choca con la pared
        if contact.bodyA.categoryBitMask == 5 && contact.bodyB.categoryBitMask == 3 || contact.bodyA.categoryBitMask == 3 && contact.bodyB.categoryBitMask == 5 {
            if contact.bodyA.categoryBitMask == 5 {
                contact.bodyA.node?.removeFromParent()
            } else {
                contact.bodyB.node?.removeFromParent()
            }
        }
    }
}

extension GameScene {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        if !gameIsPaused {
            if jumpCount < 4 {
                heroJump()
                
                
            }
            if gameLogic.currentScore >= 5 {
                print("win")
                
//                currentGameState = .playing
            }
            
        }
    }
}
