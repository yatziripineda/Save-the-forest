//
//  GameDurationView.swift
//  deforestacion
//
//  Created by yatziri on 09/02/24.
//


import SwiftUI


struct GameDurationView: View {
    @Binding var lives: Int
    
    var body: some View {
        
        ZStack{
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white.opacity(0.4))
                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
            HStack {
                ForEach(0..<lives, id: \.self) { index in
                    Image("vidas")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 50)
                }
                .padding()
            }
        }
            .frame(width: 330, height: 70)
            .padding(24)
                

        
    }
}
extension Color {
    init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0

        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        self.init(
            red: Double((rgb & 0xFF0000) >> 16) / 255.0,
            green: Double((rgb & 0x00FF00) >> 8) / 255.0,
            blue: Double(rgb & 0x0000FF) / 255.0
        )
    }
}

#Preview {
    GameDurationView(lives: .constant(3))
        .previewLayout(.fixed(width: 300, height: 100))
}

