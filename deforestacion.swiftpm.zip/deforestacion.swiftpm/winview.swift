//
//  winview.swift
//  deforestacion
//
//  Created by yatziri on 20/02/24.
//

import SwiftUI
import UIKit


struct winview: View {
    var screenSize: CGRect = CGRect.zero
    @StateObject var gameLogic: ArcadeGameLogic = ArcadeGameLogic.shared
    @State private var cloudOffset: CGFloat = 0
    @Binding var currentGameState: GameState
    
    var body: some View {
        let screenSize = UIScreen.main.bounds
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        ZStack{
            
//            VStack{
//                Image("solessss")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//            }
            VStack(alignment: .center) {
                Spacer()
                ZStack{
                    Image("winback")
                        .resizable()
//                            .aspectRatio(contentMode: .fill)
                            .frame(width: screenWidth * 2 / 3, height: screenHeight * 2 / 6)
                            
                    Image("wintext")
                        .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: screenWidth / 2,height: screenHeight/6)
                            
                        
                }
//                    .padding(.bottom, 0.0)
                Spacer()
//                    .ignoresSafeArea()
                Button {
                    withAnimation { self.backToMainScreen() }
                } label: {
                    HStack{
                        Image(systemName: "house.fill")
                        Text("Home")
                            
                    }.bold()
                        .font(.title)
                        .padding(.horizontal, 90)
                        .padding(.vertical, 20)
                        .foregroundColor(Color.black)
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.white)
                                
                                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                        )
                        .scaleEffect(currentGameState == .playing ? 0.8 : 1.0)
                }
                .padding(.top,-60)
                Button {
                    withAnimation { self.restartGame() }
                    self.gameLogic.restart_Game()
                    gameLogic.currentScore = 0
                    
                } label: {
                    HStack{
                        Image(systemName: "arrow.clockwise")
                        Text("Restart")
                            
                    }.bold()
                        .font(.title)
                        .padding(.horizontal, 90)
                        .padding(.vertical, 20)
                        .foregroundColor(Color.black)
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.white)
                                
                                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                        )
                        .scaleEffect(currentGameState == .playing ? 0.8 : 1.0)
                }
                .padding()

                Spacer()
                Spacer()
            }
        }
        .background(
            ZStack {

                solesView(offset: cloudOffset - (screenWidth / 2))
                solesView(offset: cloudOffset - (screenWidth * 3 / 2))
                
            }
        )
        .onAppear {
            withAnimation(Animation.linear(duration: 10).repeatForever(autoreverses: false)) {
                cloudOffset = screenWidth
            }
        }
        
        .statusBar(hidden: true)
    }
    
    private func backToMainScreen() {
        self.currentGameState = .firstTime
    }
    
    private func restartGame() {
        self.currentGameState = .playing
    }
}

struct solesView: View {
    var offset: CGFloat

    var body: some View {
        Image("solessss")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: UIScreen.main.bounds.size.width  )
            .offset(x: 0, y: offset)
    }
}
#Preview {
    winview(currentGameState: .constant(GameState.playing))
}





