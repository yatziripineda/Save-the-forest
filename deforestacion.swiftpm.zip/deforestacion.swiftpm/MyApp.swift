import SwiftUI

extension View {
    func horizontalOrientation() -> some View {
        self.rotationEffect(.degrees(0))
    }
}

@main
struct YourApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .horizontalOrientation() // Aplica la orientación horizontal a la vista principal
        }
    }
}
